# منشئ المواقع — Website Builder Android App

**طُوِّر بواسطة: فريق og4z**  
**قناة التلغرام:** [t.me/fareshw](https://t.me/fareshw)  
**للدفع والاشتراك:** @og4_z (نجوم تلجرام)

---

## 📱 وصف التطبيق

تطبيق Android Native متكامل يتيح للمستخدمين إنشاء مواقع ويب احترافية من وصف نصي فقط، مع استضافة دائمة لمدة سنة أو أكثر.

## ✨ المميزات

- 🚀 **إنشاء موقع بالوصف** — اكتب وصفاً وسيُنشئ الذكاء الاصطناعي موقعاً احترافياً
- 🌐 **استضافة دائمة** — استضافة لمدة سنة كاملة مع كل موقع
- 📦 **تحميل ZIP** — احصل على ملفات موقعك مضغوطة للتعديل
- 🔒 **تشفير AES-256** — حماية كاملة للبيانات عبر Android Keystore
- 👑 **نظام المدير** — أول مستخدم يصبح مديراً كاملاً
- ⭐ **تجربة مجانية** — 2 مواقع مجانية للتجربة
- 💳 **اشتراك بنجوم تلجرام** — عبر @og4_z
- 🔧 **تحسين المواقع** — اقتراحات ذكية لتحسين الجودة
- 📊 **لوحة إدارة** — مراقبة المستخدمين والمواقع

## 🏗️ هيكل المشروع

```
app/src/main/
├── AndroidManifest.xml          ← جميع الصلاحيات والأنشطة
├── java/com/og4z/websitebuilder/
│   ├── App.kt                   ← Application class
│   ├── ui/                      ← أنشطة الواجهة
│   │   ├── SplashActivity.kt
│   │   ├── OnboardingActivity.kt  (تسجيل/دخول)
│   │   ├── MainActivity.kt
│   │   ├── BuildSiteActivity.kt   (إنشاء موقع)
│   │   ├── MyWebsitesActivity.kt  (مواقعي)
│   │   ├── WebsitePreviewActivity.kt
│   │   ├── AdminActivity.kt       (لوحة المدير)
│   │   ├── PaymentActivity.kt     (الاشتراك)
│   │   ├── SettingsActivity.kt
│   │   └── ProfileActivity.kt
│   ├── data/                    ← قاعدة البيانات
│   │   ├── DatabaseHelper.kt    ← SQLite + WAL
│   │   ├── UserRepository.kt
│   │   ├── WebsiteRepository.kt
│   │   └── models/
│   │       ├── User.kt
│   │       ├── Website.kt
│   │       └── Plan.kt
│   ├── services/                ← خدمات الخلفية
│   │   ├── WebsiteUploadService.kt  (Foreground Service)
│   │   └── BackgroundSyncService.kt
│   ├── receivers/
│   │   └── BootReceiver.kt      ← تشغيل عند الإقلاع
│   ├── api/
│   │   └── WebsiteGeneratorApi.kt  ← API calls
│   └── utils/
│       ├── CryptoUtils.kt       ← AES-256-GCM عبر Keystore
│       ├── NativeCrypto.kt      ← JNI bridge للـ C++
│       ├── ZipUtils.kt          ← ضغط/فك ضغط
│       └── NetworkUtils.kt
└── cpp/                         ← C++ NDK
    ├── CMakeLists.txt
    ├── crypto_native.cpp         ← DJB2 + S-Box
    └── aes_utils.cpp
```

## 🔧 متطلبات البناء

- Android Studio Hedgehog (2023.1.1) أو أحدث
- Android SDK 34
- NDK r25c أو أحدث
- CMake 3.22.1+
- JDK 17+

## 📦 خطوات البناء

```bash
# 1. افتح المشروع في Android Studio
# 2. انتظر مزامنة Gradle
# 3. ابنِ المشروع:
./gradlew assembleDebug

# للإصدار النهائي (Release):
./gradlew assembleRelease
```

## 🔑 إعداد API

عدّل `WebsiteGeneratorApi.kt`:
```kotlin
private const val BASE_URL = "https://your-api-server.com/v1"
private const val API_KEY  = "your-api-key"
```

## 💰 نظام الاشتراك

| الخطة | السعر | المواقع | الاستضافة |
|-------|-------|---------|-----------|
| مجاني | مجاناً | 2 | شهر |
| أساسي | 50 نجمة | 10 | سنة |
| احترافي | 120 نجمة | 50 | سنتان |
| غير محدود | 250 نجمة | ∞ | 5 سنوات |

## ⚖️ حقوق الملكية

© 2024 og4z — جميع الحقوق محفوظة  
قناة التلغرام: [t.me/fareshw](https://t.me/fareshw)
