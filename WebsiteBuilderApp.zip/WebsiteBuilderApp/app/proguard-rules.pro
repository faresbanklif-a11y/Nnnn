# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified

# Keep all app classes
-keep class com.og4z.websitebuilder.** { *; }

# Keep model classes (for JSON serialization)
-keep class com.og4z.websitebuilder.data.models.** { *; }

# Keep JNI methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep NativeCrypto
-keep class com.og4z.websitebuilder.utils.NativeCrypto { *; }

# Keep Activity names (for proper reflection)
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver

# OkHttp
-dontwarn okhttp3.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }

# Glide
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { <init>(...); }

# MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# AndroidX Security
-keep class androidx.security.crypto.** { *; }

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}
