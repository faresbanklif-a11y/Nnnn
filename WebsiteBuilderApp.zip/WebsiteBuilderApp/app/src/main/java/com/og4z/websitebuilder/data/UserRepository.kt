package com.og4z.websitebuilder.data

import android.content.Context
import android.content.SharedPreferences
import com.og4z.websitebuilder.data.models.User
import com.og4z.websitebuilder.utils.CryptoUtils

object UserRepository {

    private const val PREFS_NAME   = "wb_session"
    private const val KEY_USER_ID  = "logged_user_id"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun register(username: String, email: String, password: String): Result<User> {
        val db = DatabaseHelper.instance
        if (db.getUserByEmail(email) != null)
            return Result.failure(Exception("البريد الإلكتروني مستخدم بالفعل"))

        val isFirstUser = db.getUserCount() == 0
        val user = User(
            username     = username,
            email        = email,
            passwordHash = CryptoUtils.hashPassword(password),
            isAdmin      = isFirstUser,
            createdAt    = System.currentTimeMillis()
        )
        val id = db.insertUser(user)
        if (id < 0) return Result.failure(Exception("خطأ في إنشاء الحساب"))
        db.insertLog(id, "REGISTER", "isAdmin=$isFirstUser")
        return Result.success(user.copy(id = id))
    }

    fun login(email: String, password: String): Result<User> {
        val user = DatabaseHelper.instance.getUserByEmail(email)
            ?: return Result.failure(Exception("البريد الإلكتروني غير موجود"))
        if (user.passwordHash != CryptoUtils.hashPassword(password))
            return Result.failure(Exception("كلمة المرور غير صحيحة"))
        saveSession(user.id)
        DatabaseHelper.instance.insertLog(user.id, "LOGIN", null)
        return Result.success(user)
    }

    fun getLoggedUser(): User? {
        val id = prefs.getLong(KEY_USER_ID, -1L)
        if (id < 0) return null
        return DatabaseHelper.instance.getUserById(id)
    }

    fun isLoggedIn(): Boolean = prefs.getLong(KEY_USER_ID, -1L) >= 0

    fun logout() {
        prefs.edit().remove(KEY_USER_ID).apply()
    }

    private fun saveSession(userId: Long) {
        prefs.edit().putLong(KEY_USER_ID, userId).apply()
    }
}
