package com.og4z.websitebuilder.services

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.og4z.websitebuilder.App
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.api.WebsiteGeneratorApi
import com.og4z.websitebuilder.data.WebsiteRepository
import com.og4z.websitebuilder.data.models.Website
import kotlinx.coroutines.*
import java.io.File

class WebsiteUploadService : Service() {

    companion object {
        const val EXTRA_WEBSITE_ID   = "website_id"
        const val EXTRA_DESCRIPTION  = "description"
        const val EXTRA_TITLE        = "title"
        const val EXTRA_CATEGORY     = "category"
        const val EXTRA_COLOR        = "color"
        const val EXTRA_USER_ID      = "user_id"
        const val NOTIF_ID           = 1001
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val websiteId   = intent?.getLongExtra(EXTRA_WEBSITE_ID, -1) ?: -1
        val description = intent?.getStringExtra(EXTRA_DESCRIPTION) ?: ""
        val title       = intent?.getStringExtra(EXTRA_TITLE) ?: ""
        val category    = intent?.getStringExtra(EXTRA_CATEGORY) ?: "general"
        val color       = intent?.getStringExtra(EXTRA_COLOR) ?: "#1565C0"
        val userId      = intent?.getLongExtra(EXTRA_USER_ID, -1) ?: -1

        startForeground(NOTIF_ID, buildNotification("جاري إنشاء موقعك...", 0))

        scope.launch {
            processWebsite(websiteId, description, title, category, color, userId)
        }

        return START_NOT_STICKY
    }

    private suspend fun processWebsite(
        id: Long, description: String, title: String,
        category: String, color: String, userId: Long
    ) {
        try {
            updateNotification("جاري تحليل الوصف وبناء الموقع...", 20)
            WebsiteRepository.updateStatus(id, Website.Status.GENERATING)

            val result = WebsiteGeneratorApi.generateAndDeploy(
                description, title, category, color, userId
            )

            if (!result.success) {
                WebsiteRepository.updateStatus(id, Website.Status.FAILED)
                updateNotification("فشل إنشاء الموقع: ${result.error}", 0)
                stopSelf()
                return
            }

            updateNotification("جاري رفع الملفات...", 60)
            WebsiteRepository.updateStatus(id, Website.Status.UPLOADING)

            // Download zip
            val zipFile = File(filesDir, "site_${id}.zip")
            WebsiteGeneratorApi.downloadZip(result.zipDownloadUrl, zipFile)

            updateNotification("تم! الموقع جاهز ✓", 100)
            WebsiteRepository.updateStatus(
                id, Website.Status.LIVE,
                url     = result.siteUrl,
                zipPath = zipFile.absolutePath,
                score   = result.score
            )

            sendSuccessBroadcast(id, result.siteUrl)
        } catch (e: Exception) {
            WebsiteRepository.updateStatus(id, Website.Status.FAILED)
            updateNotification("خطأ: ${e.message}", 0)
        } finally {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun buildNotification(text: String, progress: Int): Notification {
        val builder = NotificationCompat.Builder(this, App.CHANNEL_UPLOAD)
            .setContentTitle("منشئ المواقع")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (progress in 1..99)
            builder.setProgress(100, progress, false)
        else if (progress == 0)
            builder.setProgress(100, 0, true)
        return builder.build()
    }

    private fun updateNotification(text: String, progress: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text, progress))
    }

    private fun sendSuccessBroadcast(id: Long, url: String) {
        val intent = Intent("com.og4z.websitebuilder.SITE_READY").apply {
            putExtra("website_id", id)
            putExtra("url",        url)
        }
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
