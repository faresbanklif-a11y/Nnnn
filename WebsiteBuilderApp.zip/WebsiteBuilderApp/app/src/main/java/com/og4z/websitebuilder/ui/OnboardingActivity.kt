package com.og4z.websitebuilder.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.tabs.TabLayout
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.UserRepository

class OnboardingActivity : AppCompatActivity() {

    private var isLoginMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        val tabs   = findViewById<TabLayout>(R.id.tab_auth)
        val etName = findViewById<EditText>(R.id.et_username)
        val etEmail= findViewById<EditText>(R.id.et_email)
        val etPass = findViewById<EditText>(R.id.et_password)
        val btnGo  = findViewById<Button>(R.id.btn_auth_go)
        val tvChannel = findViewById<TextView>(R.id.tv_channel)
        val tvDev  = findViewById<TextView>(R.id.tv_developer)

        tvChannel.text = "قناة التلغرام: t.me/fareshw"
        tvDev.text = "طُوِّر بواسطة: فريق og4z © 2024"

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                isLoginMode = tab.position == 1
                etName.visibility = if (isLoginMode) View.GONE else View.VISIBLE
                btnGo.text = if (isLoginMode) "تسجيل الدخول" else "إنشاء حساب"
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        btnGo.setOnClickListener {
            val email    = etEmail.text.toString().trim()
            val password = etPass.text.toString()
            val username = etName.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "يرجى ملء جميع الحقول", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (isLoginMode) {
                val result = UserRepository.login(email, password)
                result.fold(
                    onSuccess = { navigateToMain() },
                    onFailure = { Toast.makeText(this, it.message, Toast.LENGTH_LONG).show() }
                )
            } else {
                if (username.isEmpty()) {
                    Toast.makeText(this, "يرجى إدخال اسم المستخدم", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val result = UserRepository.register(username, email, password)
                result.fold(
                    onSuccess = {
                        UserRepository.login(email, password)
                        navigateToMain()
                    },
                    onFailure = { Toast.makeText(this, it.message, Toast.LENGTH_LONG).show() }
                )
            }
        }
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
