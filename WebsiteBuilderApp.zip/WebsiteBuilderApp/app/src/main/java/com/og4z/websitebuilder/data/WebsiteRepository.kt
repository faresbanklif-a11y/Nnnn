package com.og4z.websitebuilder.data

import com.og4z.websitebuilder.data.models.Website

object WebsiteRepository {

    fun getUserWebsites(userId: Long): List<Website> =
        DatabaseHelper.instance.getWebsitesByUser(userId)

    fun getAllWebsites(): List<Website> =
        DatabaseHelper.instance.getAllWebsites()

    fun getById(id: Long): Website? =
        DatabaseHelper.instance.getWebsiteById(id)

    fun createWebsite(userId: Long, title: String, description: String,
                      category: String, color: String): Long {
        val w = Website(
            userId      = userId,
            title       = title,
            description = description,
            category    = category,
            colorScheme = color,
            hostingExpiry = System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000
        )
        return DatabaseHelper.instance.insertWebsite(w)
    }

    fun updateStatus(id: Long, status: Website.Status, url: String = "",
                     zipPath: String = "", score: Float = 0f) {
        DatabaseHelper.instance.updateWebsiteStatus(id, status, url, zipPath, score)
    }

    fun incrementView(id: Long) = DatabaseHelper.instance.incrementViewCount(id)
}
