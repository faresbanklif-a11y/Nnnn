package com.og4z.websitebuilder.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.WebsiteRepository
import com.og4z.websitebuilder.data.models.Website
import java.io.File

class WebsitePreviewActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_website_preview)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val websiteId = intent.getLongExtra("website_id", -1)
        val site = WebsiteRepository.getById(websiteId) ?: run {
            Toast.makeText(this, "الموقع غير موجود", Toast.LENGTH_SHORT).show()
            finish(); return
        }

        supportActionBar?.title = site.title
        WebsiteRepository.incrementView(websiteId)

        // Fill info
        findViewById<TextView>(R.id.tv_site_title_preview).text  = site.title
        findViewById<TextView>(R.id.tv_site_url_preview).text    = if (site.url.isNotEmpty()) site.url else "جاري الرفع..."
        findViewById<TextView>(R.id.tv_site_category).text       = "الفئة: ${site.category}"
        findViewById<TextView>(R.id.tv_site_status).text         = "الحالة: ${site.status.name}"
        findViewById<TextView>(R.id.tv_site_score).text          = "نقاط الجودة: ${String.format("%.0f", site.score * 100)}%"
        val days = site.daysUntilExpiry
        findViewById<TextView>(R.id.tv_site_expiry).text         = "باقي للاستضافة: $days يوم"
        findViewById<TextView>(R.id.tv_views).text               = "المشاهدات: ${site.viewCount}"

        // Description
        findViewById<TextView>(R.id.tv_description_preview).text = site.description

        // Open in browser
        val btnOpen = findViewById<MaterialButton>(R.id.btn_open_browser)
        if (site.url.isNotEmpty()) {
            btnOpen.setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(site.url)))
            }
        } else {
            btnOpen.isEnabled = false
            btnOpen.text = "الرابط غير متاح بعد"
        }

        // Share link
        val btnShare = findViewById<MaterialButton>(R.id.btn_share)
        btnShare.setOnClickListener {
            if (site.url.isEmpty()) {
                Toast.makeText(this, "الموقع لم يُنشر بعد", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val shareText = "🌐 شاهد موقعي: ${site.title}\n${site.url}\n\nصُنع بواسطة تطبيق منشئ المواقع | t.me/fareshw"
            startActivity(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
            })
        }

        // Download ZIP
        val btnDownload = findViewById<MaterialButton>(R.id.btn_download_zip)
        if (site.localZipPath.isNotEmpty() && File(site.localZipPath).exists()) {
            btnDownload.setOnClickListener {
                val zipFile = File(site.localZipPath)
                val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", zipFile)
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/zip")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }
        } else {
            btnDownload.isEnabled = false
            btnDownload.text = "الملف غير متاح"
        }

        // Improvements
        val tvImprovements = findViewById<TextView>(R.id.tv_improvements)
        if (site.score < 0.8f && site.isLive) {
            tvImprovements.visibility = View.VISIBLE
            tvImprovements.text = "💡 اقتراحات لتحسين موقعك:\n• أضف المزيد من المحتوى\n• أضف صوراً عالية الجودة\n• تحقق من الكلمات المفتاحية"
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
