package com.og4z.websitebuilder.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.og4z.websitebuilder.services.BackgroundSyncService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            val svc = Intent(context, BackgroundSyncService::class.java)
            context.startForegroundService(svc)
        }
    }
}
