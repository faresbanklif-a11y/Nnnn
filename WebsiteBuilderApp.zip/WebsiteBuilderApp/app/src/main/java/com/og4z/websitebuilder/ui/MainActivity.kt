package com.og4z.websitebuilder.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.UserRepository
import com.og4z.websitebuilder.data.WebsiteRepository

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))

        val user = UserRepository.getLoggedUser() ?: run {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish(); return
        }

        // Header
        findViewById<TextView>(R.id.tv_welcome).text = "مرحباً، ${user.username} 👋"
        val plan = if (user.isPaid) "مشترك ✓" else "مجاني (${user.trialSitesUsed}/2)"
        findViewById<TextView>(R.id.tv_plan_status).text = "الخطة: $plan"

        val websites = WebsiteRepository.getUserWebsites(user.id)
        findViewById<TextView>(R.id.tv_sites_count).text = "مواقعك: ${websites.size}"
        val live = websites.count { it.isLive }
        findViewById<TextView>(R.id.tv_live_count).text = "مواقع نشطة: $live"

        // Admin badge
        if (user.isAdmin) {
            val adminBadge = findViewById<TextView>(R.id.tv_admin_badge)
            adminBadge.visibility = android.view.View.VISIBLE
        }

        // Buttons
        findViewById<MaterialButton>(R.id.btn_build_site).setOnClickListener {
            if (!user.isPaid && !user.canCreateFreeSite) {
                startActivity(Intent(this, PaymentActivity::class.java))
                Toast.makeText(this, "استنفدت تجربتك المجانية، يرجى الاشتراك", Toast.LENGTH_LONG).show()
            } else {
                startActivity(Intent(this, BuildSiteActivity::class.java))
            }
        }

        findViewById<MaterialButton>(R.id.btn_my_sites).setOnClickListener {
            startActivity(Intent(this, MyWebsitesActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btn_upgrade).setOnClickListener {
            startActivity(Intent(this, PaymentActivity::class.java))
        }

        // Channel card
        findViewById<MaterialCardView>(R.id.card_channel).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/fareshw")))
        }

        if (user.isAdmin) {
            findViewById<MaterialCardView>(R.id.card_admin).apply {
                visibility = android.view.View.VISIBLE
                setOnClickListener { startActivity(Intent(this@MainActivity, AdminActivity::class.java)) }
            }
        }

        // Developer credit footer
        findViewById<TextView>(R.id.tv_footer).text = "© 2024 og4z — جميع الحقوق محفوظة | t.me/fareshw"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
            R.id.action_profile  -> { startActivity(Intent(this, ProfileActivity::class.java)); true }
            R.id.action_logout   -> { UserRepository.logout(); startActivity(Intent(this, OnboardingActivity::class.java)); finish(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh user data
        val user = UserRepository.getLoggedUser() ?: return
        val websites = WebsiteRepository.getUserWebsites(user.id)
        findViewById<TextView>(R.id.tv_sites_count).text = "مواقعك: ${websites.size}"
    }
}
