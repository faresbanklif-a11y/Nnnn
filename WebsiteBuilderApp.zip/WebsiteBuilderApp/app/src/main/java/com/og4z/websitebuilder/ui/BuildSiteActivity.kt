package com.og4z.websitebuilder.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputEditText
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.UserRepository
import com.og4z.websitebuilder.data.WebsiteRepository
import com.og4z.websitebuilder.services.WebsiteUploadService

class BuildSiteActivity : AppCompatActivity() {

    private val categories = listOf("متجر إلكتروني","مدونة","شركة","محفظة أعمال","خدمات","تعليمي","ترفيهي","شخصي")
    private val colors     = listOf("#1565C0","#2E7D32","#6A1B9A","#BF360C","#00838F","#F9A825","#263238")

    private var selectedCategory = "متجر إلكتروني"
    private var selectedColor    = "#1565C0"
    private var pendingWebsiteId = -1L

    private val siteReadyReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val id  = intent.getLongExtra("website_id", -1)
            val url = intent.getStringExtra("url") ?: ""
            if (id == pendingWebsiteId && id >= 0) {
                runOnUiThread {
                    hideProgress()
                    Toast.makeText(ctx, "✅ تم إنشاء موقعك!", Toast.LENGTH_LONG).show()
                    val nav = Intent(this@BuildSiteActivity, WebsitePreviewActivity::class.java)
                    nav.putExtra("website_id", id)
                    startActivity(nav)
                    finish()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_build_site)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "إنشاء موقع جديد"

        registerReceiver(siteReadyReceiver,
            IntentFilter("com.og4z.websitebuilder.SITE_READY"),
            RECEIVER_NOT_EXPORTED)

        setupCategoryChips()
        setupColorPicker()
        setupBuildButton()
    }

    private fun setupCategoryChips() {
        val group = findViewById<ChipGroup>(R.id.chip_group_category)
        categories.forEach { cat ->
            val chip = Chip(this).apply {
                text = cat
                isCheckable = true
                isChecked = cat == selectedCategory
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) selectedCategory = cat
            }
            group.addView(chip)
        }
    }

    private fun setupColorPicker() {
        val group = findViewById<ChipGroup>(R.id.chip_group_color)
        colors.forEach { hex ->
            val chip = Chip(this).apply {
                text = "  "
                isCheckable = true
                isChecked = hex == selectedColor
                setChipBackgroundColorResource(android.R.color.transparent)
                chipStrokeWidth = 2f
                setTextColor(android.graphics.Color.parseColor(hex))
                chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor(hex))
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) selectedColor = hex
            }
            group.addView(chip)
        }
    }

    private fun setupBuildButton() {
        val etTitle = findViewById<TextInputEditText>(R.id.et_site_title)
        val etDesc  = findViewById<TextInputEditText>(R.id.et_description)
        val btnBuild= findViewById<MaterialButton>(R.id.btn_build)

        btnBuild.setOnClickListener {
            val title = etTitle.text.toString().trim()
            val desc  = etDesc.text.toString().trim()

            if (title.isEmpty()) { etTitle.error = "أدخل اسم الموقع"; return@setOnClickListener }
            if (desc.length < 20) { etDesc.error = "أدخل وصفاً أوضح (20 حرف على الأقل)"; return@setOnClickListener }

            val user = UserRepository.getLoggedUser() ?: return@setOnClickListener

            // Create DB record first
            pendingWebsiteId = WebsiteRepository.createWebsite(
                user.id, title, desc, selectedCategory, selectedColor
            )

            if (!user.isPaid) {
                WebsiteRepository    // will be managed on server side too
            }

            showProgress()

            // Start background service
            val svc = Intent(this, WebsiteUploadService::class.java).apply {
                putExtra(WebsiteUploadService.EXTRA_WEBSITE_ID,  pendingWebsiteId)
                putExtra(WebsiteUploadService.EXTRA_DESCRIPTION, desc)
                putExtra(WebsiteUploadService.EXTRA_TITLE,       title)
                putExtra(WebsiteUploadService.EXTRA_CATEGORY,    selectedCategory)
                putExtra(WebsiteUploadService.EXTRA_COLOR,       selectedColor)
                putExtra(WebsiteUploadService.EXTRA_USER_ID,     user.id)
            }
            startForegroundService(svc)
        }
    }

    private fun showProgress() {
        findViewById<View>(R.id.layout_progress).visibility = View.VISIBLE
        findViewById<MaterialButton>(R.id.btn_build).isEnabled = false
    }

    private fun hideProgress() {
        findViewById<View>(R.id.layout_progress).visibility = View.GONE
        findViewById<MaterialButton>(R.id.btn_build).isEnabled = true
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    override fun onDestroy() {
        unregisterReceiver(siteReadyReceiver)
        super.onDestroy()
    }
}
