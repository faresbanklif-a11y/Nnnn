package com.og4z.websitebuilder.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.UserRepository
import com.og4z.websitebuilder.data.WebsiteRepository
import com.og4z.websitebuilder.data.models.Website

class MyWebsitesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_websites)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "مواقعي"

        val user     = UserRepository.getLoggedUser() ?: return
        val websites = WebsiteRepository.getUserWebsites(user.id)

        val rv = findViewById<RecyclerView>(R.id.rv_websites)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = WebsitesAdapter(websites) { site ->
            val intent = Intent(this, WebsitePreviewActivity::class.java)
            intent.putExtra("website_id", site.id)
            startActivity(intent)
        }

        val empty = findViewById<View>(R.id.layout_empty)
        empty.visibility = if (websites.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    class WebsitesAdapter(
        private val list: List<Website>,
        private val onClick: (Website) -> Unit
    ) : RecyclerView.Adapter<WebsitesAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvTitle    : TextView = view.findViewById(R.id.tv_site_title)
            val tvUrl      : TextView = view.findViewById(R.id.tv_site_url)
            val tvDate     : TextView = view.findViewById(R.id.tv_site_date)
            val tvExpiry   : TextView = view.findViewById(R.id.tv_expiry)
            val chipStatus : Chip     = view.findViewById(R.id.chip_status)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_website, parent, false))

        override fun getItemCount() = list.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val site = list[position]
            holder.tvTitle.text  = site.title
            holder.tvUrl.text    = if (site.url.isNotEmpty()) site.url else "لم ينشر بعد"
            holder.tvDate.text   = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                .format(java.util.Date(site.createdAt))
            holder.tvExpiry.text = "تنتهي الاستضافة بعد: ${site.daysUntilExpiry} يوم"
            holder.chipStatus.text = when (site.status) {
                Website.Status.LIVE      -> "✅ نشط"
                Website.Status.GENERATING-> "⚙️ يُنشأ"
                Website.Status.UPLOADING -> "⬆️ يُرفع"
                Website.Status.FAILED    -> "❌ فشل"
                Website.Status.IMPROVING -> "🔧 يُحسَّن"
                else                     -> "⏳ معلق"
            }
            holder.itemView.setOnClickListener { onClick(site) }
        }
    }
}
