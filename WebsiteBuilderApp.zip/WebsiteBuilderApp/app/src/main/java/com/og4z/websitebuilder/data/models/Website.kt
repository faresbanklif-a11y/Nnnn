package com.og4z.websitebuilder.data.models

data class Website(
    val id: Long = 0,
    val userId: Long,
    val title: String,
    val description: String,
    val url: String = "",
    val localZipPath: String = "",
    val status: Status = Status.PENDING,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val category: String = "general",
    val colorScheme: String = "#1565C0",
    val hostingExpiry: Long = System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000,
    val viewCount: Int = 0,
    val score: Float = 0f
) {
    enum class Status { PENDING, GENERATING, UPLOADING, LIVE, FAILED, IMPROVING }

    val isLive: Boolean get() = status == Status.LIVE
    val daysUntilExpiry: Long get() = (hostingExpiry - System.currentTimeMillis()) / (24 * 60 * 60 * 1000)
}
