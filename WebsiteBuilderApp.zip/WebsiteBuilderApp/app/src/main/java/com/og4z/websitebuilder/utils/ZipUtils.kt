package com.og4z.websitebuilder.utils

import java.io.*
import java.util.zip.*

object ZipUtils {

    fun zipFolder(sourceFolder: File, zipFile: File): Boolean {
        return try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                addFolderToZip(sourceFolder, sourceFolder.name, zos)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun addFolderToZip(folder: File, parentPath: String, zos: ZipOutputStream) {
        folder.listFiles()?.forEach { file ->
            val entryName = "$parentPath/${file.name}"
            if (file.isDirectory) {
                addFolderToZip(file, entryName, zos)
            } else {
                zos.putNextEntry(ZipEntry(entryName))
                FileInputStream(file).use { fis -> fis.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    fun unzip(zipFile: File, destFolder: File): Boolean {
        return try {
            destFolder.mkdirs()
            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val outFile = File(destFolder, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { zis.copyTo(it) }
                    }
                    entry = zis.nextEntry
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun calculateSizeKB(folder: File): Long {
        var size = 0L
        folder.walkTopDown().forEach { if (it.isFile) size += it.length() }
        return size / 1024
    }
}
