package com.og4z.websitebuilder.utils

/**
 * JNI bridge to the C++ native crypto library (libwb_native.so).
 * Handles fast hashing, license validation, and memory obfuscation.
 */
object NativeCrypto {

    init {
        System.loadLibrary("wb_native")
    }

    /** Fast DJB2-based hash using S-Box substitution from native layer */
    external fun nativeFastHash(input: String): String

    /** Validate a license key against a user ID natively */
    external fun validateLicenseKey(key: String, userId: String): Boolean

    /** XOR obfuscate byte array with rotating key (in-memory protection) */
    external fun obfuscate(data: ByteArray, key: Byte): ByteArray

    /** Convenience: deobfuscate is the same XOR operation */
    fun deobfuscate(data: ByteArray, key: Byte): ByteArray = obfuscate(data, key)

    /** Check if native library loaded successfully */
    fun isAvailable(): Boolean = try { nativeFastHash("test"); true } catch (e: UnsatisfiedLinkError) { false }
}
