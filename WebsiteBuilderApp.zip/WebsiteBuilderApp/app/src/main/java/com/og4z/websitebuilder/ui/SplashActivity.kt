package com.og4z.websitebuilder.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.UserRepository

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        UserRepository.init(this)

        val logo = findViewById<ImageView>(R.id.iv_splash_logo)
        val name = findViewById<TextView>(R.id.tv_app_name)
        val slogan = findViewById<TextView>(R.id.tv_slogan)

        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        val slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_up)
        logo.startAnimation(fadeIn)
        name.startAnimation(slideUp)
        slogan.startAnimation(slideUp)

        Handler(Looper.getMainLooper()).postDelayed({
            val destination = if (UserRepository.isLoggedIn()) {
                MainActivity::class.java
            } else {
                OnboardingActivity::class.java
            }
            startActivity(Intent(this, destination))
            finish()
        }, 2500)
    }
}
