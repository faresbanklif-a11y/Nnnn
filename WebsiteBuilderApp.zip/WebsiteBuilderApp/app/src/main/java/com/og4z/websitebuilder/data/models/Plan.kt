package com.og4z.websitebuilder.data.models

data class Plan(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val price: Int,         // Stars count
    val sitesAllowed: Int,
    val hostingMonths: Int,
    val features: List<String>
)

object Plans {
    val TRIAL = Plan("trial","مجاني","Free",0,2,1,
        listOf("موقعان مجانيان","استضافة شهر","دعم أساسي"))

    val BASIC = Plan("basic","أساسي","Basic",50,10,12,
        listOf("10 مواقع","استضافة سنة كاملة","دعم متقدم","تحليلات","رفع مخصص"))

    val PRO = Plan("pro","احترافي","Pro",120,50,24,
        listOf("50 موقع","استضافة سنتان","دعم أولوية","تحليلات متقدمة","نطاق مخصص","شهادة SSL"))

    val UNLIMITED = Plan("unlimited","غير محدود","Unlimited",250,-1,60,
        listOf("مواقع غير محدودة","استضافة 5 سنوات","دعم فوري 24/7","كل المميزات","API Access","White Label"))

    val all = listOf(TRIAL, BASIC, PRO, UNLIMITED)
}
