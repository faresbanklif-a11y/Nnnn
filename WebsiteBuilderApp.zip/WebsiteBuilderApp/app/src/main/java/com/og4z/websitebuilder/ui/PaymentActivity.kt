package com.og4z.websitebuilder.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.DatabaseHelper
import com.og4z.websitebuilder.data.UserRepository
import com.og4z.websitebuilder.data.models.Plans
import kotlinx.coroutines.*

class PaymentActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "الاشتراك والدفع"

        val user = UserRepository.getLoggedUser() ?: return

        // Plan cards info
        val tv = findViewById<TextView>(R.id.tv_plans_info)
        val sb = StringBuilder()
        Plans.all.filter { it.id != "trial" }.forEach { plan ->
            sb.append("🌟 ${plan.nameAr} — ${plan.price} نجمة تلجرام\n")
            sb.append("   • ${plan.sitesAllowed} موقع | ${plan.hostingMonths} شهر استضافة\n")
            plan.features.forEach { f -> sb.append("   ✓ $f\n") }
            sb.append("\n")
        }
        tv.text = sb.toString()

        // Payment instructions
        findViewById<TextView>(R.id.tv_payment_instructions).text = """
            طريقة الدفع بنجوم تلجرام:
            
            1. افتح تلجرام وابحث عن @og4_z
            2. أرسل رسالة بالخطة المطلوبة والمبلغ
            3. أرسل النجوم عبر زر "إرسال هدية" في تلجرام
            4. انتظر تأكيد الدفع وسيتم تفعيل اشتراكك تلقائياً
            
            للدعم والاستفسارات: @og4_z
            قناة التحديثات: t.me/fareshw
        """.trimIndent()

        // Open Telegram to pay
        findViewById<MaterialButton>(R.id.btn_pay_telegram).setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/og4_z"))
            startActivity(intent)
        }

        // Check payment status (simulate with a simple input for now)
        val etTelegram = findViewById<EditText>(R.id.et_telegram_username)
        val btnVerify  = findViewById<MaterialButton>(R.id.btn_verify_payment)

        btnVerify.setOnClickListener {
            val tg = etTelegram.text.toString().trim()
            if (tg.isEmpty()) {
                etTelegram.error = "أدخل اسم المستخدم في تلجرام"
                return@setOnClickListener
            }
            btnVerify.isEnabled = false
            btnVerify.text = "جاري التحقق..."

            scope.launch {
                delay(1500) // Simulate network call
                // In production, call WebsiteGeneratorApi.verifyPayment(...)
                // For demo, mark as paid after Telegram confirmation
                withContext(Dispatchers.Main) {
                    DatabaseHelper.instance.updateUserPlan(user.id, "basic", true)
                    Toast.makeText(this@PaymentActivity,
                        "✅ تم التحقق! جاري تفعيل اشتراكك...", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }

        // Channel button
        findViewById<MaterialButton>(R.id.btn_open_channel).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/fareshw")))
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
