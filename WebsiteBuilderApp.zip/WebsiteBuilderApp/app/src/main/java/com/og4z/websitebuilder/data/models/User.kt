package com.og4z.websitebuilder.data.models

data class User(
    val id: Long = 0,
    val username: String,
    val email: String,
    val passwordHash: String,
    val isAdmin: Boolean = false,
    val isPaid: Boolean = false,
    val trialSitesUsed: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val telegramUsername: String = "",
    val avatarPath: String = ""
) {
    val canCreateFreeSite: Boolean get() = trialSitesUsed < 2
    val hasPremium: Boolean get() = isPaid
}
