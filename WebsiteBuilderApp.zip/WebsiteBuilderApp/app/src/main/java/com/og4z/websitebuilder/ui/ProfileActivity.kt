package com.og4z.websitebuilder.ui

import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.UserRepository
import com.og4z.websitebuilder.data.WebsiteRepository

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "الملف الشخصي"

        val user = UserRepository.getLoggedUser() ?: return
        val sites = WebsiteRepository.getUserWebsites(user.id)

        findViewById<TextView>(R.id.tv_profile_name).text  = user.username
        findViewById<TextView>(R.id.tv_profile_email).text = user.email
        val plan = if (user.isAdmin) "مدير النظام 👑" else if (user.isPaid) "مشترك ⭐" else "مجاني"
        findViewById<TextView>(R.id.tv_profile_plan).text  = "الخطة: $plan"
        findViewById<TextView>(R.id.tv_profile_sites).text = "إجمالي المواقع: ${sites.size}"
        val liveSites = sites.count { it.isLive }
        findViewById<TextView>(R.id.tv_live_sites_profile).text = "مواقع نشطة: $liveSites"
        val totalViews = sites.sumOf { it.viewCount }
        findViewById<TextView>(R.id.tv_total_views).text = "إجمالي المشاهدات: $totalViews"
        val regDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            .format(java.util.Date(user.createdAt))
        findViewById<TextView>(R.id.tv_reg_date).text = "تاريخ التسجيل: $regDate"
    }
    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
