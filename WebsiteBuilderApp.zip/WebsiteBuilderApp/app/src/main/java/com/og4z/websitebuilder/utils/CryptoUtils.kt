package com.og4z.websitebuilder.utils

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object CryptoUtils {

    private const val KEY_ALIAS    = "WB_MASTER_KEY_V1"
    private const val KEYSTORE     = "AndroidKeyStore"
    private const val CIPHER_ALGO  = "AES/GCM/NoPadding"
    private const val GCM_TAG_LEN  = 128

    private lateinit var appContext: Context

    fun init(context: Context) {
        appContext = context.applicationContext
        generateKeyIfAbsent()
    }

    private fun generateKeyIfAbsent() {
        val ks = KeyStore.getInstance(KEYSTORE).also { it.load(null) }
        if (ks.containsAlias(KEY_ALIAS)) return
        KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE).apply {
            init(
                KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setUserAuthenticationRequired(false)
                    .build()
            )
            generateKey()
        }
    }

    private fun getSecretKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE).also { it.load(null) }
        return ks.getKey(KEY_ALIAS, null) as SecretKey
    }

    fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(CIPHER_ALGO)
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv  = cipher.iv
        val enc = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        // Prepend IV to ciphertext, then base64 encode
        val combined = iv + enc
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    fun decrypt(encBase64: String): String {
        val combined = Base64.decode(encBase64, Base64.NO_WRAP)
        val iv  = combined.copyOfRange(0, 12)
        val enc = combined.copyOfRange(12, combined.size)
        val cipher = Cipher.getInstance(CIPHER_ALGO)
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), GCMParameterSpec(GCM_TAG_LEN, iv))
        return String(cipher.doFinal(enc), Charsets.UTF_8)
    }

    fun sha256(input: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        val hash   = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }

    fun hashPassword(password: String, salt: String = "WB_SALT_2024"): String =
        sha256(salt + password + salt.reversed())
}
