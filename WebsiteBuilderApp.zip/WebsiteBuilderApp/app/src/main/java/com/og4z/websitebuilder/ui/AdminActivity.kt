package com.og4z.websitebuilder.ui

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.DatabaseHelper
import com.og4z.websitebuilder.data.UserRepository
import com.og4z.websitebuilder.data.WebsiteRepository

class AdminActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "لوحة الإدارة"

        val admin = UserRepository.getLoggedUser()
        if (admin == null || !admin.isAdmin) {
            Toast.makeText(this, "غير مصرح لك بالدخول", Toast.LENGTH_LONG).show()
            finish(); return
        }

        val users    = DatabaseHelper.instance.getAllUsers()
        val websites = WebsiteRepository.getAllWebsites()
        val live     = websites.count { it.isLive }
        val paid     = users.count { it.isPaid }

        // Stats
        findViewById<TextView>(R.id.tv_total_users).text    = "المستخدمون: ${users.size}"
        findViewById<TextView>(R.id.tv_paid_users).text     = "المشتركون: $paid"
        findViewById<TextView>(R.id.tv_total_sites).text    = "المواقع: ${websites.size}"
        findViewById<TextView>(R.id.tv_live_sites).text     = "المواقع النشطة: $live"
        findViewById<TextView>(R.id.tv_revenue).text        = "الإيرادات: ${paid * 50}+ نجمة"

        // Users list
        val rv = findViewById<RecyclerView>(R.id.rv_admin_users)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int) =
                object : RecyclerView.ViewHolder(
                    android.view.LayoutInflater.from(parent.context)
                        .inflate(android.R.layout.simple_list_item_2, parent, false)
                ) {}

            override fun getItemCount() = users.size

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val u = users[position]
                holder.itemView.findViewById<TextView>(android.R.id.text1).text =
                    "${u.username} ${if (u.isAdmin) "(مدير)" else ""} ${if (u.isPaid) "✓ مدفوع" else ""}"
                holder.itemView.findViewById<TextView>(android.R.id.text2).text =
                    "${u.email} | مواقع: ${websites.count { it.userId == u.id }}"
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
