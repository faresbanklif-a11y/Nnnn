package com.og4z.websitebuilder.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.og4z.websitebuilder.data.models.User
import com.og4z.websitebuilder.data.models.Website
import com.og4z.websitebuilder.utils.CryptoUtils

class DatabaseHelper private constructor(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "websitebuilder_encrypted.db"
        private const val DB_VERSION = 3
        lateinit var instance: DatabaseHelper
            private set

        fun init(context: Context) {
            instance = DatabaseHelper(context.applicationContext)
        }

        // Table names
        private const val TBL_USERS    = "users"
        private const val TBL_WEBSITES = "websites"
        private const val TBL_SESSIONS = "sessions"
        private const val TBL_LOGS     = "app_logs"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TBL_USERS (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                username        TEXT NOT NULL UNIQUE,
                email           TEXT NOT NULL UNIQUE,
                password_hash   TEXT NOT NULL,
                is_admin        INTEGER DEFAULT 0,
                is_paid         INTEGER DEFAULT 0,
                plan_id         TEXT DEFAULT 'trial',
                trial_used      INTEGER DEFAULT 0,
                telegram_user   TEXT DEFAULT '',
                avatar_path     TEXT DEFAULT '',
                created_at      INTEGER NOT NULL,
                updated_at      INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE $TBL_WEBSITES (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id         INTEGER NOT NULL,
                title           TEXT NOT NULL,
                description     TEXT NOT NULL,
                url             TEXT DEFAULT '',
                local_zip_path  TEXT DEFAULT '',
                status          TEXT DEFAULT 'PENDING',
                category        TEXT DEFAULT 'general',
                color_scheme    TEXT DEFAULT '#1565C0',
                hosting_expiry  INTEGER NOT NULL,
                view_count      INTEGER DEFAULT 0,
                score           REAL DEFAULT 0,
                created_at      INTEGER NOT NULL,
                updated_at      INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES $TBL_USERS(id)
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE $TBL_SESSIONS (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                token       TEXT NOT NULL,
                created_at  INTEGER NOT NULL,
                expires_at  INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE $TBL_LOGS (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER,
                action      TEXT NOT NULL,
                detail      TEXT,
                ip_hash     TEXT,
                created_at  INTEGER NOT NULL
            )
        """.trimIndent())

        // Indexes
        db.execSQL("CREATE INDEX idx_websites_user ON $TBL_WEBSITES(user_id)")
        db.execSQL("CREATE INDEX idx_sessions_user ON $TBL_SESSIONS(user_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE $TBL_USERS ADD COLUMN plan_id TEXT DEFAULT 'trial'")
        if (oldVersion < 3) db.execSQL("ALTER TABLE $TBL_WEBSITES ADD COLUMN score REAL DEFAULT 0")
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        // Enable WAL for better concurrent performance
        db.enableWriteAheadLogging()
    }

    // ─── USER OPERATIONS ────────────────────────────────────────────────────────

    fun insertUser(user: User): Long {
        val cv = ContentValues().apply {
            put("username",      user.username)
            put("email",         user.email)
            put("password_hash", user.passwordHash)
            put("is_admin",      if (user.isAdmin) 1 else 0)
            put("is_paid",       if (user.isPaid) 1 else 0)
            put("plan_id",       "trial")
            put("trial_used",    user.trialSitesUsed)
            put("telegram_user", user.telegramUsername)
            put("avatar_path",   user.avatarPath)
            put("created_at",    user.createdAt)
            put("updated_at",    System.currentTimeMillis())
        }
        return writableDatabase.insert(TBL_USERS, null, cv)
    }

    fun getUserByEmail(email: String): User? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TBL_USERS WHERE email = ? LIMIT 1", arrayOf(email)
        )
        return cursor.use {
            if (!it.moveToFirst()) return null
            mapUser(it)
        }
    }

    fun getUserById(id: Long): User? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TBL_USERS WHERE id = ?", arrayOf(id.toString())
        )
        return cursor.use { if (!it.moveToFirst()) null else mapUser(it) }
    }

    fun getUserCount(): Int {
        val c = readableDatabase.rawQuery("SELECT COUNT(*) FROM $TBL_USERS", null)
        return c.use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    fun updateUserPlan(userId: Long, planId: String, isPaid: Boolean) {
        val cv = ContentValues().apply {
            put("plan_id",    planId)
            put("is_paid",    if (isPaid) 1 else 0)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.update(TBL_USERS, cv, "id = ?", arrayOf(userId.toString()))
    }

    fun incrementTrialUsed(userId: Long) {
        writableDatabase.execSQL(
            "UPDATE $TBL_USERS SET trial_used = trial_used + 1, updated_at = ? WHERE id = ?",
            arrayOf(System.currentTimeMillis(), userId)
        )
    }

    fun getAllUsers(): List<User> {
        val list = mutableListOf<User>()
        val c = readableDatabase.rawQuery("SELECT * FROM $TBL_USERS ORDER BY created_at DESC", null)
        c.use { while (it.moveToNext()) list.add(mapUser(it)) }
        return list
    }

    private fun mapUser(c: android.database.Cursor) = User(
        id              = c.getLong(c.getColumnIndexOrThrow("id")),
        username        = c.getString(c.getColumnIndexOrThrow("username")),
        email           = c.getString(c.getColumnIndexOrThrow("email")),
        passwordHash    = c.getString(c.getColumnIndexOrThrow("password_hash")),
        isAdmin         = c.getInt(c.getColumnIndexOrThrow("is_admin")) == 1,
        isPaid          = c.getInt(c.getColumnIndexOrThrow("is_paid")) == 1,
        trialSitesUsed  = c.getInt(c.getColumnIndexOrThrow("trial_used")),
        telegramUsername= c.getString(c.getColumnIndexOrThrow("telegram_user")),
        avatarPath      = c.getString(c.getColumnIndexOrThrow("avatar_path")),
        createdAt       = c.getLong(c.getColumnIndexOrThrow("created_at"))
    )

    // ─── WEBSITE OPERATIONS ─────────────────────────────────────────────────────

    fun insertWebsite(w: Website): Long {
        val cv = ContentValues().apply {
            put("user_id",        w.userId)
            put("title",          w.title)
            put("description",    CryptoUtils.encrypt(w.description))
            put("url",            w.url)
            put("local_zip_path", w.localZipPath)
            put("status",         w.status.name)
            put("category",       w.category)
            put("color_scheme",   w.colorScheme)
            put("hosting_expiry", w.hostingExpiry)
            put("view_count",     w.viewCount)
            put("score",          w.score)
            put("created_at",     w.createdAt)
            put("updated_at",     w.updatedAt)
        }
        return writableDatabase.insert(TBL_WEBSITES, null, cv)
    }

    fun updateWebsiteStatus(id: Long, status: Website.Status, url: String = "", zipPath: String = "", score: Float = 0f) {
        val cv = ContentValues().apply {
            put("status",         status.name)
            put("updated_at",     System.currentTimeMillis())
            if (url.isNotEmpty())     put("url",            url)
            if (zipPath.isNotEmpty()) put("local_zip_path", zipPath)
            if (score > 0f)           put("score",          score)
        }
        writableDatabase.update(TBL_WEBSITES, cv, "id = ?", arrayOf(id.toString()))
    }

    fun getWebsitesByUser(userId: Long): List<Website> {
        val list = mutableListOf<Website>()
        val c = readableDatabase.rawQuery(
            "SELECT * FROM $TBL_WEBSITES WHERE user_id = ? ORDER BY created_at DESC",
            arrayOf(userId.toString())
        )
        c.use { while (it.moveToNext()) list.add(mapWebsite(it)) }
        return list
    }

    fun getWebsiteById(id: Long): Website? {
        val c = readableDatabase.rawQuery(
            "SELECT * FROM $TBL_WEBSITES WHERE id = ?", arrayOf(id.toString())
        )
        return c.use { if (!it.moveToFirst()) null else mapWebsite(it) }
    }

    fun getAllWebsites(): List<Website> {
        val list = mutableListOf<Website>()
        val c = readableDatabase.rawQuery(
            "SELECT * FROM $TBL_WEBSITES ORDER BY created_at DESC", null
        )
        c.use { while (it.moveToNext()) list.add(mapWebsite(it)) }
        return list
    }

    fun incrementViewCount(id: Long) {
        writableDatabase.execSQL(
            "UPDATE $TBL_WEBSITES SET view_count = view_count + 1 WHERE id = ?", arrayOf(id)
        )
    }

    private fun mapWebsite(c: android.database.Cursor) = Website(
        id             = c.getLong(c.getColumnIndexOrThrow("id")),
        userId         = c.getLong(c.getColumnIndexOrThrow("user_id")),
        title          = c.getString(c.getColumnIndexOrThrow("title")),
        description    = try { CryptoUtils.decrypt(c.getString(c.getColumnIndexOrThrow("description"))) }
                         catch (e: Exception) { c.getString(c.getColumnIndexOrThrow("description")) },
        url            = c.getString(c.getColumnIndexOrThrow("url")),
        localZipPath   = c.getString(c.getColumnIndexOrThrow("local_zip_path")),
        status         = Website.Status.valueOf(c.getString(c.getColumnIndexOrThrow("status"))),
        category       = c.getString(c.getColumnIndexOrThrow("category")),
        colorScheme    = c.getString(c.getColumnIndexOrThrow("color_scheme")),
        hostingExpiry  = c.getLong(c.getColumnIndexOrThrow("hosting_expiry")),
        viewCount      = c.getInt(c.getColumnIndexOrThrow("view_count")),
        score          = c.getFloat(c.getColumnIndexOrThrow("score")),
        createdAt      = c.getLong(c.getColumnIndexOrThrow("created_at")),
        updatedAt      = c.getLong(c.getColumnIndexOrThrow("updated_at"))
    )

    // ─── LOG OPERATIONS ─────────────────────────────────────────────────────────

    fun insertLog(userId: Long?, action: String, detail: String?) {
        val cv = ContentValues().apply {
            put("user_id",   userId ?: -1L)
            put("action",    action)
            put("detail",    detail ?: "")
            put("created_at",System.currentTimeMillis())
        }
        writableDatabase.insert(TBL_LOGS, null, cv)
    }

    fun clearOldLogs(olderThanMs: Long = 30L * 24 * 60 * 60 * 1000) {
        writableDatabase.execSQL(
            "DELETE FROM $TBL_LOGS WHERE created_at < ?",
            arrayOf(System.currentTimeMillis() - olderThanMs)
        )
    }
}
