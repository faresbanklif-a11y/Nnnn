package com.og4z.websitebuilder.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Connects to the AI generation + hosting backend.
 * Replace BASE_URL with your actual deployed API endpoint.
 */
object WebsiteGeneratorApi {

    private const val BASE_URL   = "https://api.og4z-websitebuilder.com/v1"
    private const val API_KEY    = "YOUR_SERVER_API_KEY_HERE"   // Set in BuildConfig
    private const val TIMEOUT_MS = 120_000                       // 2 minutes

    data class GenerateResult(
        val success: Boolean,
        val siteUrl: String = "",
        val zipDownloadUrl: String = "",
        val score: Float = 0f,
        val improvements: List<String> = emptyList(),
        val error: String = ""
    )

    /** Generate a full website from a textual description and deploy it. */
    suspend fun generateAndDeploy(
        description: String,
        title: String,
        category: String,
        colorScheme: String,
        userId: Long
    ): GenerateResult = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("description",   description)
                put("title",         title)
                put("category",      category)
                put("color_scheme",  colorScheme)
                put("user_id",       userId)
                put("hosting_years", 1)
            }.toString()

            val json = post("$BASE_URL/websites/generate", body)
            val obj  = JSONObject(json)

            if (!obj.getBoolean("success"))
                return@withContext GenerateResult(false, error = obj.optString("message"))

            val data  = obj.getJSONObject("data")
            val imprArr = data.optJSONArray("improvements")
            val improvements = buildList {
                if (imprArr != null)
                    for (i in 0 until imprArr.length()) add(imprArr.getString(i))
            }

            GenerateResult(
                success        = true,
                siteUrl        = data.getString("site_url"),
                zipDownloadUrl = data.getString("zip_url"),
                score          = data.optDouble("score", 0.0).toFloat(),
                improvements   = improvements
            )
        } catch (e: Exception) {
            GenerateResult(false, error = e.message ?: "خطأ في الاتصال")
        }
    }

    /** Download the site ZIP file to local storage. */
    suspend fun downloadZip(zipUrl: String, destFile: File): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val conn = URL(zipUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_MS
                conn.readTimeout    = TIMEOUT_MS
                conn.inputStream.use { ins ->
                    FileOutputStream(destFile).use { fos -> ins.copyTo(fos) }
                }
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }

    /** Check hosting status for a site. */
    suspend fun checkHostingStatus(siteUrl: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val conn = URL(siteUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.requestMethod  = "HEAD"
            conn.responseCode in 200..399
        } catch (e: Exception) { false }
    }

    /** Verify a Telegram Stars payment. */
    suspend fun verifyPayment(
        userId: Long, planId: String, telegramUsername: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("user_id",          userId)
                put("plan_id",          planId)
                put("telegram_username",telegramUsername)
            }.toString()
            val json = post("$BASE_URL/payments/verify", body)
            JSONObject(json).getBoolean("verified")
        } catch (e: Exception) { false }
    }

    private fun post(endpoint: String, body: String): String {
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        conn.requestMethod  = "POST"
        conn.connectTimeout = TIMEOUT_MS
        conn.readTimeout    = TIMEOUT_MS
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        conn.setRequestProperty("Authorization", "Bearer $API_KEY")
        conn.doOutput = true
        conn.outputStream.use {
            it.write(body.toByteArray(StandardCharsets.UTF_8))
        }
        return conn.inputStream.bufferedReader().readText()
    }
}
