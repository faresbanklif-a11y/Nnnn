package com.og4z.websitebuilder.ui

import android.os.Bundle
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.og4z.websitebuilder.R
import com.og4z.websitebuilder.data.DatabaseHelper

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "الإعدادات"

        val prefs = getSharedPreferences("wb_settings", MODE_PRIVATE)

        val swNotif = findViewById<Switch>(R.id.sw_notifications)
        swNotif.isChecked = prefs.getBoolean("notifications", true)
        swNotif.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("notifications", checked).apply()
        }

        val swDark = findViewById<Switch>(R.id.sw_dark_mode)
        swDark.isChecked = prefs.getBoolean("dark_mode", false)
        swDark.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("dark_mode", checked).apply()
            Toast.makeText(this, "سيُطبق عند إعادة فتح التطبيق", Toast.LENGTH_SHORT).show()
        }

        val swWifi = findViewById<Switch>(R.id.sw_wifi_only)
        swWifi.isChecked = prefs.getBoolean("wifi_only", false)
        swWifi.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("wifi_only", checked).apply()
        }

        findViewById<MaterialButton>(R.id.btn_clear_cache).setOnClickListener {
            DatabaseHelper.instance.clearOldLogs()
            cacheDir.deleteRecursively()
            Toast.makeText(this, "تم مسح الذاكرة المؤقتة", Toast.LENGTH_SHORT).show()
        }

        val tvVersion = findViewById<TextView>(R.id.tv_version)
        tvVersion.text = "الإصدار: 1.0.0 | © 2024 og4z\nقناة التلغرام: t.me/fareshw"
    }
    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
