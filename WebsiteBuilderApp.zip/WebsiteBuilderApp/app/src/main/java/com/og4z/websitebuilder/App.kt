package com.og4z.websitebuilder

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.og4z.websitebuilder.data.DatabaseHelper
import com.og4z.websitebuilder.utils.CryptoUtils

class App : Application() {

    companion object {
        lateinit var instance: App
            private set
        const val CHANNEL_UPLOAD    = "ch_upload"
        const val CHANNEL_GENERAL   = "ch_general"
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        DatabaseHelper.init(this)
        CryptoUtils.init(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_UPLOAD, "رفع المواقع", NotificationManager.IMPORTANCE_LOW)
                    .also { it.description = "تتبع عملية رفع وإنشاء المواقع" }
            )
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_GENERAL, "إشعارات عامة", NotificationManager.IMPORTANCE_DEFAULT)
                    .also { it.description = "إشعارات التطبيق العامة" }
            )
        }
    }
}
