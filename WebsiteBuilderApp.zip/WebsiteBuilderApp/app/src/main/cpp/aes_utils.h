#pragma once
#include <cstdint>
#include <cstddef>

uint8_t  wb_substitute(uint8_t byte);
void     wb_xor_block(const uint8_t* a, const uint8_t* b, uint8_t* out, size_t len);
uint32_t wb_rotate_left(uint32_t val, int shift);
