#include <jni.h>
#include <string>
#include <android/log.h>
#include <cstring>
#include <cstdlib>
#include "aes_utils.h"

#define LOG_TAG "WB_Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Native fast hash for integrity checks
extern "C" JNIEXPORT jstring JNICALL
Java_com_og4z_websitebuilder_utils_NativeCrypto_nativeFastHash(
        JNIEnv* env,
        jobject /* this */,
        jstring input) {
    const char* str = env->GetStringUTFChars(input, nullptr);
    if (!str) return env->NewStringUTF("error");

    // DJB2 hash
    uint64_t hash = 5381ULL;
    for (size_t i = 0; str[i]; i++) {
        uint8_t sub = wb_substitute((uint8_t)str[i]);
        hash = ((hash << 5) + hash) ^ sub;
    }

    char result[32];
    snprintf(result, sizeof(result), "%016llx", (unsigned long long)hash);
    env->ReleaseStringUTFChars(input, str);
    LOGI("nativeFastHash computed");
    return env->NewStringUTF(result);
}

// Validate license key native-side
extern "C" JNIEXPORT jboolean JNICALL
Java_com_og4z_websitebuilder_utils_NativeCrypto_validateLicenseKey(
        JNIEnv* env,
        jobject /* this */,
        jstring key,
        jstring userId) {
    const char* k  = env->GetStringUTFChars(key,    nullptr);
    const char* uid= env->GetStringUTFChars(userId, nullptr);

    uint64_t kHash   = 5381ULL;
    uint64_t uidHash = 5381ULL;
    for (size_t i = 0; k[i];   i++) kHash   = ((kHash   << 5) + kHash)   ^ wb_substitute((uint8_t)k[i]);
    for (size_t i = 0; uid[i]; i++) uidHash = ((uidHash << 5) + uidHash) ^ wb_substitute((uint8_t)uid[i]);

    env->ReleaseStringUTFChars(key,    k);
    env->ReleaseStringUTFChars(userId, uid);

    // Simple license validation: key XOR hash must match pattern
    bool valid = (kHash ^ uidHash) % 7 == 0;
    LOGI("validateLicenseKey: %s", valid ? "VALID" : "INVALID");
    return (jboolean)valid;
}

// Native XOR obfuscation for sensitive strings in memory
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_og4z_websitebuilder_utils_NativeCrypto_obfuscate(
        JNIEnv* env,
        jobject /* this */,
        jbyteArray data,
        jbyte key) {
    jsize  len  = env->GetArrayLength(data);
    jbyte* buf  = env->GetByteArrayElements(data, nullptr);
    jbyteArray result = env->NewByteArray(len);
    jbyte* out  = env->GetByteArrayElements(result, nullptr);
    for (jsize i = 0; i < len; i++) {
        out[i] = (jbyte)(buf[i] ^ (key + i));
    }
    env->ReleaseByteArrayElements(data,   buf, JNI_ABORT);
    env->ReleaseByteArrayElements(result, out, 0);
    return result;
}
